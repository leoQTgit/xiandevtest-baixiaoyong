#include "askwindow.h"

AskWindow::AskWindow(QWidget *parent) : QWidget(parent)
{
    createCancelPage();
    toCopyPage();
    toCopyPastPage();
   connect(m_copyPastBtn,&DPushButton::clicked,this,&AskWindow::sendSlot);
}

DWidget* AskWindow::createCopyPastPage()
{

    // 验证码
    copyPastWidget = new DWidget;
    QFont v_font("宋体",10,QFont::Thin,true);
    v_font.setLetterSpacing(QFont::AbsoluteSpacing,5 );
    m_textLabel2 =new DLabel(copyPastWidget);
    m_textLabel2->setFont(v_font);
    m_textLabel2->setText(tr("Successfully copied "));
    m_textLabel2->setAlignment(Qt::AlignCenter);


    //　加载文字
    QString text = QString(tr("\t waiting for connection, please wait..."
                             "\r\n this interface will be automatically hidden\r\n "
                              "to the taskbar after successful connection"));
    QFont str_font("宋体",8,QFont::Thin,true);
    m_stringLabel2 =new DLabel(text,copyPastWidget);
    m_stringLabel2->setFont(str_font);
    m_stringLabel2->setAlignment(Qt::AlignCenter);

    //　加载按钮
    m_copyPastBtn = new DPushButton(tr("cancel"),copyPastWidget);


    //添加控件
    vLayout3 =new QVBoxLayout;
    vLayout3->addWidget(m_textLabel2, 0, Qt::AlignCenter);
    vLayout3->addWidget(m_stringLabel2, 0, Qt::AlignCenter);
    vLayout3->addWidget(m_copyPastBtn, 0, Qt::AlignCenter);

    copyPastWidget->setLayout(vLayout3);
    return copyPastWidget;

}

DWidget* AskWindow::createCopyPage()
{
    // 验证码
    copyWidget = new DWidget;
    QFont font("宋体",14,QFont::Thin,true);
    font.setLetterSpacing(QFont::AbsoluteSpacing,15 );
    m_textLabel1 =new DLabel(copyWidget);
    m_textLabel1->setFont(font);
    m_textLabel1->setAlignment(Qt::AlignCenter);
    int num=getRandomNumber(0,999999);
    QString str = QString::number(num);
    strNum=str;
    m_textLabel1->setText(str);

    //　加载文字
    QString text = QString(tr("To start sharing your desktop, put the above verification code \r\n"
                              "Provided to personnel assisting you after they input \n verification code"
                              ", your Shared drawing will begin immediately"));
    QFont s_font("宋体",8,QFont::Thin,true);
    m_stringLabel1 =new DLabel(text,copyWidget);
    m_stringLabel1->setFont(s_font);
    m_stringLabel1->setAlignment(Qt::AlignCenter);

    //　加载按钮
    m_copyBtn = new DPushButton(tr("copy"),copyWidget);


    //添加控件
    vLayout2 =new QVBoxLayout;
    vLayout2->addWidget(m_textLabel1, 0, Qt::AlignCenter);
    vLayout2->addWidget(m_stringLabel1, 0, Qt::AlignCenter);
    vLayout2->addWidget(m_copyBtn, 0, Qt::AlignCenter);

    copyWidget->setLayout(vLayout2);
    return copyWidget;

}


DWidget* AskWindow::createCancelPage()
{    
//     加载动态图标
    widget = new DWidget;
    m_pSpinner =new DSpinner(widget);
    m_pSpinner->setFixedSize(32,32);
    m_pSpinner->start();

//    　加载文字
    QString text = QString(tr("Request verification code is being generated, please wait..."));
    m_stringLabel =new DLabel(text,widget);
    QFont s_font("宋体",8,QFont::Thin,true);
    m_stringLabel->setFont(s_font);

//  　加载按钮
    m_cancelBtn = new DPushButton(tr("cancel"),widget);
    connect(m_cancelBtn,&DPushButton::clicked,this,&AskWindow::sendSlot);


//    添加控件
    vLayout =new QVBoxLayout;
    vLayout->addWidget(m_pSpinner, 0, Qt::AlignCenter);
    vLayout->addWidget(m_stringLabel, 0, Qt::AlignCenter);
    vLayout->addWidget(m_cancelBtn, 0, Qt::AlignCenter);

    widget->setLayout(vLayout);



    m_pStackedWidget = new QStackedWidget;
    m_pStackedWidget->addWidget(widget);
    m_pStackedWidget->addWidget(createCopyPage());
    m_pStackedWidget->addWidget(createCopyPastPage());
    mainVLayout = new QVBoxLayout;
    mainVLayout->addWidget(m_pStackedWidget);
    setLayout(mainVLayout);

    return widget;
}



void AskWindow::sendSlot()
{
    emit cancelSignal();

}

int AskWindow::getRandomNumber(int min,int max)
{
    qsrand(QTime(0, 0, 0).secsTo(QTime::currentTime()));

    int num = qrand()%(max-min);
//    qDebug()<<num+min;
    return num;
}



void AskWindow::setClipboard()
{
    board = QApplication::clipboard();
    board->setText(m_textLabel1->text());
}

void AskWindow::getClipboard()
{
    board = QApplication::clipboard();
    QString str = board->text();

}
void AskWindow::toCopyPage()
{
    timer = new QTimer;
    timer->start(2000);
    connect(timer,&QTimer::timeout,[=](){
        m_pStackedWidget->setCurrentWidget(copyWidget);
        if(m_textLabel1->text() != "")
        {
           timer->stop();
        }

    });

}
void AskWindow::toCopyPastPage()
{
    connect(m_copyBtn,&DPushButton::clicked,[=](){
        setClipboard();
        m_pStackedWidget->setCurrentWidget(copyPastWidget);
        timer2 = new QTimer;
        timer2->start(3000);
        connect(timer2,&QTimer::timeout,[=](){

            if(m_textLabel2->text() != "")
            {
               timer2->stop();
            }
            sendSlot();
            this->hide();
        });
    });

}
